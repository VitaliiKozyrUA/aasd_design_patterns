﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L2.observer
{
    class $safeitemname$ : IObserver
    {
        public void Update()
        {
            Console.WriteLine("$safeitemname$ received an update.");
        }
    }
}
